
from django.contrib import admin
from django.urls import path
from Attendance import views
from django.conf.urls import include
from django.conf.urls import url
urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/',include('allauth.urls')),
    path('',views.login_page,name='login'),
 	path('sec/',views.sec,name='details'),
    path('signup/',views.signup,name='register'),
    path('individual/',views.ind_update,name='individual'),
    path('add/',views.add_details,name='update'),
    path('del/',views.del_details,name='delete'),
    #path('temp/',views.temp,name='temp'),
 	#path('upload/',views.add_list,name='list1'),
 	path('update/',views.your_list,name='upload'),
 	path('update_phn/',views.update_phn,name='phone'),
 	path('update_reg/',views.update_reg,name='reg'),
 	path('update_name/',views.name_update,name='update_name'),
 	
 	 
]
