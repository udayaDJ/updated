from django.db import models

class Addlist(models.Model):
	