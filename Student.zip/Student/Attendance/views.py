from django.shortcuts import render
from django.shortcuts import redirect,render_to_response
from django.contrib.auth.forms import UserCreationForm
from django.http.response import HttpResponse
from django.template import RequestContext
from Attendance import forms
from .forms import success,phone,UploadFileForm,register,name,add_det
from django.contrib.auth import authenticate, login, logout
import gspread
from oauth2client.service_account import ServiceAccountCredentials

def login_page(request):
	if request.method=="POST":
		form=success(request.POST)
		if form.is_valid():
			user_name=request.POST.get("username")
			raw_password=request.POST.get("password1")
			user=authenticate(request,username=user_name,password=raw_password)
			if user is not None:
				login(request,user)
				return render(request,"Attendance/details.html")
	else:
		form=success()
		return render(request,'Attendance/login.html',{"form":form})

def signup(request):
	if request.method=="POST":
		form=UserCreationForm(request.POST)
		print(form)
		if form.is_valid():
			form.save()
			user_name=form.cleaned_data['username']
			passw=form.cleaned_data['password1']
			user=authenticate(username=user_name,password=passw)
			login(request,user)
			print(user.is_authenticated)
			return render(request,'Attendance/login.html')
		
	form=UserCreationForm(None)
	return render(request,'Attendance/signup.html',{"form":form})
def sec(request):
	return render(request,'Attendance/details.html')
def ind_update(request):
	return render(request,"Attendance/individual.html")
def add_list(request):
	return redirect("https://docs.google.com/spreadsheets/d/1iCnNiTWBaQ_PI0CIwUbD012kpTNR1yp1jUH0U357pwM/edit#gid=0")
def your_list(request):
	scope = ['https://www.googleapis.com/auth/drive','https://spreadsheets.google.com/feeds']
	cr=ServiceAccountCredentials.from_json_keyfile_name('Attendance/sms.json',scope)
	gc=gspread.authorize(cr)
	wks=gc.open('YourList').sheet1
	return redirect("/sec")
def update_phn(request):
	if request.method=="POST":
		scope = ['https://www.googleapis.com/auth/drive','https://spreadsheets.google.com/feeds']
		cr=ServiceAccountCredentials.from_json_keyfile_name('Attendance/sms.json',scope)
		gc=gspread.authorize(cr)
		wks=gc.open('YourList').sheet1
		form=phone(request.POST)
		if form.is_valid():
			old=request.POST.get("old_no")
			new=request.POST.get("new_no")
			print("Working")
			a=wks.find(old)
			wks.update_cell(a.row,a.col,new)
		return redirect("/sec")
	else:
		form=phone()
		return render(request,"Attendance/phone.html",{"form":form})
def update_reg(request):
	if request.method=="POST":
		scope = ['https://www.googleapis.com/auth/drive','https://spreadsheets.google.com/feeds']
		cr=ServiceAccountCredentials.from_json_keyfile_name('Attendance/sms.json',scope)
		gc=gspread.authorize(cr)
		wks=gc.open('YourList').sheet1
		form=phone(request.POST)
		if form.is_valid():
			old=request.POST.get("old_reg")
			new=request.POST.get("new_reg")
			a=wks.find(old)
			wks.update_cell(a.row,a.col,new)
		return redirect("/individual")
	else:
		form=register()
		return render(request,"Attendance/update_reg.html",{"form":form})
def name_update(request):
	if request.method=="POST":
		scope = ['https://www.googleapis.com/auth/drive','https://spreadsheets.google.com/feeds']
		cr=ServiceAccountCredentials.from_json_keyfile_name('Attendance/sms.json',scope)
		gc=gspread.authorize(cr)
		wks=gc.open('YourList').sheet1
		form=name(request.POST)
		if form.is_valid():
			old=request.POST.get("reg_num")
			new=request.POST.get("name_update")
			a=wks.find(old)
			b=a.col
			wks.update_cell(a.row,b+1,new)
		return redirect("/individual")
	else:
		form=name()
		return render(request,"Attendance/update_name.html",{"form":form})

def add_details(request):
	if request.method=="POST":
		scope = ['https://www.googleapis.com/auth/drive','https://spreadsheets.google.com/feeds']
		cr=ServiceAccountCredentials.from_json_keyfile_name('Attendance/sms.json',scope)
		gc=gspread.authorize(cr)
		wks=gc.open('YourList').sheet1
		form=add_det(request.POST)
		if form.is_valid():
			Name=request.POST.get("name")
			Reg=request.POST.get("register_no")
			phn=request.POST.get("phn_no")
			print(Name,Reg,phn)
			wks.append_row([Reg,Name,phn])

		return redirect("/sec")
	form=add_det(None)
	return render(request,'Attendance/add_data.html',{"form":form})


def del_details(request):
	if request.method=="POST":
		scope = ['https://www.googleapis.com/auth/drive','https://spreadsheets.google.com/feeds']
		cr=ServiceAccountCredentials.from_json_keyfile_name('Attendance/sms.json',scope)
		gc=gspread.authorize(cr)
		wks=gc.open('YourList').sheet1
		form=add_det(request.POST)
		if form.is_valid():
			Register=request.POST.get("register_no")
			r=wks.find(Register)
			wks.delete_row(r.row)
			return redirect("/sec")
	form=add_det(None)
	return render(request,'Attendance/del_data.html',{"form":form})